CSRF Scanner Extenstion for Burp Suite Pro
=

Requirements
-

* Burp Suite Pro

If you want to compile the code from scratch, you will also need the following:

* [JSoup library](http://jsoup.org) (either compile into the .jar or copy to Burp's Java Environment directory)
* [Burp Extender API](http://portswigger.net/burp/extender/api/burp_extender_api.zip)
